package com.hfad.g4prescriptiontracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class G4PrescriptionTrackerDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "PrescriptionDb"; // the name of our database
    private static final int DB_VERSION = 1; // the version of the database

    G4PrescriptionTrackerDatabaseHelper(Context context) {

        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + G4Contract.G4PrescriptionDBEntry.TABLE_NAME + "("
                + G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_RXNUMBER + " TEXT, "
                + G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_MEDICATIONNAME + " TEXT, "
                + G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_REFILLS + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + G4Contract.G4PrescriptionDBEntry.TABLE_NAME);
        onCreate(db);
    }

    public void insertPrescription(String rxNumber,
                                   String medicationName,
                                   String refills) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues prescriptionValues = new ContentValues();
        prescriptionValues.put("RXNUMBER", rxNumber);
        prescriptionValues.put("MEDICATIONNAME", medicationName);
        prescriptionValues.put("REFILLS", refills);
        db.insert(G4Contract.G4PrescriptionDBEntry.TABLE_NAME, null, prescriptionValues);
    }

    public void deletePrescription(SQLiteDatabase db, int id) {
        db.delete(G4Contract.G4PrescriptionDBEntry.TABLE_NAME,
                "_id = ?",
                new String[] {String.valueOf(id)});
    }
}
