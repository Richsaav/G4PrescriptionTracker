package com.hfad.g4prescriptiontracker;

import android.app.Activity;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.view.View.OnClickListener;



public class TopLevelActivity extends Activity implements OnClickListener {

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_level);

        button1 = (Button) findViewById(R.id.button_add);
        button2 = (Button) findViewById(R.id.button_modify);
        button3 = (Button) findViewById(R.id.button_delete);
        button4 = (Button) findViewById(R.id.button_display);
        button5 = (Button) findViewById(R.id.button_find);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);


    }

    @Override
    public void onClick (View view){
        switch (view.getId()) {
            case R.id.button_add:
                Intent intent1 = new Intent(TopLevelActivity.this,
                        PrescriptionTrackerAdd.class);
                startActivity(intent1);
                break;
            case R.id.button_modify:
                Intent intent2 = new Intent(TopLevelActivity.this,
                        PrescriptionTrackerModify.class);
                startActivity(intent2);
                break;
            case R.id.button_delete:
                Intent intent3 = new Intent(TopLevelActivity.this,
                        PrescriptionTrackerDelete.class);
                startActivity(intent3);
                break;
            case R.id.button_display:
                Intent intent4 = new Intent(TopLevelActivity.this,
                        PrescriptionTrackerDisplay.class);
                startActivity(intent4);
                break;
            case R.id.button_find:
                Intent intent5 = new Intent(TopLevelActivity.this,
                        PrescriptionTrackerFind.class);
                startActivity(intent5);
                break;
        }
    }
}
