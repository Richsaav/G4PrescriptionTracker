package com.hfad.g4prescriptiontracker;

import androidx.appcompat.app.AppCompatActivity;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.TableRow;

public class PrescriptionTrackerDisplay extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_tracker_display);
        // Create DatabaseHelper instance
        G4PrescriptionTrackerDatabaseHelper dbHelper = new
                G4PrescriptionTrackerDatabaseHelper(this);
        TableLayout tableLayout = (TableLayout) findViewById(R.id.tableLayout);
        // Add header row
        TableRow columnHeaders = new TableRow(this);
        columnHeaders.setBackgroundColor(Color.parseColor("#c0c0c0"));
        columnHeaders.setLayoutParams(new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));
        String[] headerText = {"ID", "Rx Number", "Med Name", "Refills"};
        for (String c : headerText) {
            TextView rx = new TextView(this);
            rx.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT));
            rx.setGravity(Gravity.CENTER);
            rx.setTextSize(18);
            rx.setPadding(5, 5, 5, 5);
            rx.setText(c);
            columnHeaders.addView(rx);
        }
        tableLayout.addView(columnHeaders);

        // Get data from sqlite database and add them to the table
        // Open the database for reading
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Start the transaction.


        try {

            Cursor cursor = db.rawQuery("Select * from " +
                            G4Contract.G4PrescriptionDBEntry.TABLE_NAME, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    // Read columns data
                    int id = cursor.getInt(0);
                    String rxText = cursor.getString(1);
                    String medText = cursor.getString(2);
                    String refillText = cursor.getString(3);

                    // dara rows
                    TableRow dataRow = new TableRow(this);
                    dataRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.
                            LayoutParams.MATCH_PARENT,
                            TableLayout.LayoutParams.WRAP_CONTENT));
                    String[] colText={String.valueOf(id),rxText,medText,refillText};
                    for (String text : colText) {
                        TextView rx = new TextView(this);
                        rx.setLayoutParams(new TableRow.LayoutParams(
                                TableRow.LayoutParams.WRAP_CONTENT,
                                TableRow.LayoutParams.WRAP_CONTENT));
                        rx.setGravity(Gravity.CENTER);
                        rx.setTextSize(16);
                        rx.setPadding(5, 5, 5, 5);
                        rx.setText(text);
                        dataRow.addView(rx);
                    }
                    tableLayout.addView(dataRow);

                }

            }
            cursor.close();
        } catch (SQLiteException e) {
            e.printStackTrace();

        } finally {

            // End the transaction.
            db.close();
            // Close database
        }
    }
}

