package com.hfad.g4prescriptiontracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;

public class PrescriptionTrackerDelete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_tracker_delete);
    }

//    public void onRadioButtonClicked(View view) {
//        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
//        int id = radioGroup.getCheckedRadioButtonId();
//    }
}
