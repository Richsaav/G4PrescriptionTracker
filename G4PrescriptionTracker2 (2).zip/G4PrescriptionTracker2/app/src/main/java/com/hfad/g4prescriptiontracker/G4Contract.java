package com.hfad.g4prescriptiontracker;

public class G4Contract {

    private G4Contract() {}

    public static class G4PrescriptionDBEntry {
        public static final String TABLE_NAME = "Prescriptions";
        public static final String COLUMN_NAME_RXNUMBER = "RXNUMBER";
        public static final String COLUMN_NAME_MEDICATIONNAME = "MEDICATIONNAME";
        public static final String COLUMN_NAME_REFILLS = "REFILLS";
    }
}
