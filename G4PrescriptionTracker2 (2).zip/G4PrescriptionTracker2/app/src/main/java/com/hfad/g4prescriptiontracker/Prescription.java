package com.hfad.g4prescriptiontracker;

import android.widget.Spinner;

public class Prescription {

    private String rxNumber;
    private String MedicationName;
    private String refills;

    public Prescription(String rxnumber, String medicationname, String refills) {

        this.rxNumber = rxnumber;
        this.MedicationName = medicationname;
        this.refills = refills;
    }

    public String getRxNumber() {
        return rxNumber;
    }

    public void setRxNumber(String rxNumber) {
        this.rxNumber = rxNumber;
    }

    public String getMedicationName() {
        return MedicationName;
    }

    public void setMedicationName(String medicationName) {
        MedicationName = medicationName;
    }

    public String getRefills() {
        return refills;
    }

    public void setRefills(String refills) {
        this.refills = refills;
    }




}
