package com.hfad.g4prescriptiontracker;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
public class PrescriptionTrackerDisplay extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_tracker_display);


    displayAllPrescriptions();
    }



    public void displayAllPrescriptions() {

        SQLiteOpenHelper DBHelper = new G4PrescriptionTrackerDatabaseHelper(this);

    try {
        SQLiteDatabase db = DBHelper.getReadableDatabase();

        Cursor cursor = db.query(G4Contract.G4PrescriptionDBEntry.TABLE_NAME,
                new String[] {"_id", G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_RXNUMBER,
                        G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_MEDICATIONNAME,
                        G4Contract.G4PrescriptionDBEntry.COLUMN_NAME_REFILLS},
                        null,null,null,null,null);

        //Move to the first record in the cursor
        if (cursor.moveToFirst()) {

            //Get the prescription details from the cursor
//            int iDText = cursor.getInt(0);
            String rxText = cursor.getString(1);
            String medText = cursor.getString(2);
            String refillText = cursor.getString(3);



            TextView rxNumber = (TextView)findViewById(R.id.rxNumber_display);
            rxNumber.setText(rxText);

            TextView medName = (TextView)findViewById(R.id.medicationName_display);
            medName.setText(medText);

            TextView refills = (TextView)findViewById(R.id.refills_display);
            refills.setText(refillText);

        }
        cursor.close();
        db.close();

    } catch (SQLiteException e) {
        Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
        toast.show();
    }

    }
}


