package com.hfad.g4prescriptiontracker;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.View.OnClickListener;

public class PrescriptionTrackerAdd extends AppCompatActivity implements OnClickListener{

    G4PrescriptionTrackerDatabaseHelper db;
    EditText rxNumber, medicationName, refillsInput;
    Button btnAdd, btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_tracker_add);
        db = new G4PrescriptionTrackerDatabaseHelper(this);
        rxNumber = (EditText) findViewById(R.id.rxNumber_input);
        medicationName = (EditText) findViewById(R.id.medication_input);
        refillsInput = (EditText) findViewById(R.id.refills_spinner);
        btnAdd = (Button) findViewById(R.id.btnAddSubmit);
        btnCancel = (Button) findViewById(R.id.btnAddCancel);

        btnAdd.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btnAddSubmit:
                db.insertPrescription(rxNumber.getText().toString(),
                        medicationName.getText().toString(), refillsInput.getText().toString());
                Intent intent = new Intent(PrescriptionTrackerAdd.this, TopLevelActivity.class);
                startActivity(intent);
                break;
            case R.id.btnAddCancel:
                Intent intent1 = new Intent(PrescriptionTrackerAdd.this, TopLevelActivity.class);
                startActivity(intent1);
                break;
        }
    }
}